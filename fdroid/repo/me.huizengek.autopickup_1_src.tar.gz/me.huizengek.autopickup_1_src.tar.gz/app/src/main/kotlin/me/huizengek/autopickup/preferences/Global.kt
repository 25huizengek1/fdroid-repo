package me.huizengek.autopickup.preferences

import me.huizengek.autopickup.Dependencies

open class GlobalPreferencesHolder : PreferencesHolder(Dependencies.application, "preferences")
