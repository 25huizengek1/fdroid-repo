package it.vfsfitvnm.vimusic.utils

val Int.mb get() = this * 1_048_576L
