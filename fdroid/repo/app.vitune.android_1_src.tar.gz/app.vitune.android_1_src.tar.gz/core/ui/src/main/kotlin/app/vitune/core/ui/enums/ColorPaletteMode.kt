package app.vitune.core.ui.enums

enum class ColorPaletteMode {
    Light,
    Dark,
    System
}
