package app.vitune.core.data.enums

enum class SongSortBy {
    PlayTime,
    Title,
    DateAdded
}
