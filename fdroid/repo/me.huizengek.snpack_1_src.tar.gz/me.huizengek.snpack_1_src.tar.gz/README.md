# snpack

Een Nederlandse, advertentievrije WhatsApp sticker maker.

---

## Screenshots

<p align="center">
  <img src="./fastlane/metadata/android/nl-NL/images/phoneScreenshots/1-light_static_home.png" width="30%" alt="Screenshot" />
  <img src="./fastlane/metadata/android/nl-NL/images/phoneScreenshots/2-light_static_new_pack.png" width="30%" alt="Screenshot" />
  <img src="./fastlane/metadata/android/nl-NL/images/phoneScreenshots/3-light_static_settings.png" width="30%" alt="Screenshot" />

  <img src="./fastlane/metadata/android/nl-NL/images/phoneScreenshots/7-dark_static_home.png" width="30%" alt="Screenshot" />
  <img src="./fastlane/metadata/android/nl-NL/images/phoneScreenshots/8-dark_static_new_pack.png" width="30%" alt="Screenshot" />
  <img src="./fastlane/metadata/android/nl-NL/images/phoneScreenshots/9-dark_static_settings.png" width="30%" alt="Screenshot" />
</p>

## Licentie

De broncode van dit project is gelicenseerd onder de GNU GPLv3 licentie, een kopie ervan is te
vinden in `LICENSE`.