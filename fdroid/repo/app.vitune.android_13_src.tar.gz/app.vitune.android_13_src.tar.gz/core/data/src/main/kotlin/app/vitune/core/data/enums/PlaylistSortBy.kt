package app.vitune.core.data.enums

enum class PlaylistSortBy {
    Name,
    DateAdded,
    SongCount
}
