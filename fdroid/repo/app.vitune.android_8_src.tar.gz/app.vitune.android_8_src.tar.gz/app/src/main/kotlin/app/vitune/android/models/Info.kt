package app.vitune.android.models

data class Info(
    val id: String,
    val name: String?
)
