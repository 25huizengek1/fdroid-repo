package app.vitune.core.data.utils

val Int.mb get() = this * 1_048_576L
