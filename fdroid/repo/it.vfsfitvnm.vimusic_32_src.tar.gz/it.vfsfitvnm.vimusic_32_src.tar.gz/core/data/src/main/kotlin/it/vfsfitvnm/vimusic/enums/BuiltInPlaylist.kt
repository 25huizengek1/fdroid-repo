package it.vfsfitvnm.vimusic.enums

enum class BuiltInPlaylist {
    Favorites,
    Offline,
    Top
}
