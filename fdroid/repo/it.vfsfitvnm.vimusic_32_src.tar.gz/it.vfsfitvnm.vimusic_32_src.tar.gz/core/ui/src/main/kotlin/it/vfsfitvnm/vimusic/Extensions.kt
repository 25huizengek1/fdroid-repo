package it.vfsfitvnm.vimusic

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.Dp

val Dp.roundedShape get() = RoundedCornerShape(this)
