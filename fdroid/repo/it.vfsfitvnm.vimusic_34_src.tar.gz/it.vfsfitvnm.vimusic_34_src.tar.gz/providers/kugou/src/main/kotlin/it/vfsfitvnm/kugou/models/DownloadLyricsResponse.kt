package it.vfsfitvnm.kugou.models

import kotlinx.serialization.Serializable

@Serializable
internal class DownloadLyricsResponse(
    val content: String
)
