---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''
---

## Feature request: ...

A clear and concise description of the feature you want to request.
