package app.vitune.core.data.enums

enum class AlbumSortBy {
    Title,
    Year,
    DateAdded
}
