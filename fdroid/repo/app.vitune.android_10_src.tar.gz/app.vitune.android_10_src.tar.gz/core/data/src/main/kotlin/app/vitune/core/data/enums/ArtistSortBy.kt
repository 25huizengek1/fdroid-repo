package app.vitune.core.data.enums

enum class ArtistSortBy {
    Name,
    DateAdded
}
