package app.vitune.core.data.enums

enum class BuiltInPlaylist {
    Favorites,
    Offline,
    Top,
    History
}
